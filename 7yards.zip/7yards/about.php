<?php include 'header.php'; ?>
    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">About Us</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">About</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- about-area -->
        <section class="about__area-three about__bg-two" data-background="assets/img/bg/h3_about_bg.jpg">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="about__img-wrap-three">
                            <img src="assets/img/images/h3_about_img01.jpg" alt="">
                            <!--<img src="assets/img/images/h3_about_img02.jpg" alt="" data-parallax='{"x" : 50 }'>-->
                            <div class="shape">
                                <img src="assets/img/images/h3_about_img_shape.png" alt="" class="alltuchtopdown">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about__content-three">
                            <div class="section-title mb-25">
                                <span class="sub-title">About Our Company</span>
                                <h2 class="title">Offering Expert Guidance in IT Consulting, Planning, and Achieving Business Success</h2>
                            </div>
                            <p>At 7Yards Solutions, we're more than just a digital marketing and website development agency – we're your partners in success. With a passion for innovation and a commitment to excellence, we strive to empower businesses of all sizes to thrive in the ever-evolving digital landscape.</p>
                            <div class="about__content-inner about__content-inner-two">
                                <div class="experience__box-three">
                                    <div class="title">
                                        <span>25</span>
                                    </div>
                                    <p>Years <span>Experience</span> in Consulting</p>
                                </div>
                                <div class="about__list-box about__list-box-two">
                                    <ul class="list-wrap">
                                        <li><i class="flaticon-arrow-button"></i>Proven Track Record</li>
                                        <li><i class="flaticon-arrow-button"></i>Transparent Communication</li>
                                        <li><i class="flaticon-arrow-button"></i>Cutting-Edge Solutions</li>
                                        <li><i class="flaticon-arrow-button"></i>Dedicated Support</li>
                                    </ul>
                                </div>
                            </div>
                          
                            <div class="about__shape-wrap-three">
                                <img src="assets/img/images/h3_about_shape01.png" alt="" class="rotateme">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-area-end -->
     
        <!-- counter-area-end -->
        <!-- request-area -->
        <section class="request__area-two">
            <div class="request__bg-two" data-background="assets/img/bg/h2_request_bg.jpg"></div>
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-xl-5 col-lg-6">
                        <div class="request__content-two">
                            <h2 class="title">Giving The Greatest <span>Experience for</span> your  Organisation.</h2>
                            <div class="request__phone">
                                <div class="icon">
                                    <i class="flaticon-phone-call"></i>
                                </div>
                                <div class="content">
                                    <span>Toll Free Call</span>
                                    <a href="tel:+91 93373 19419">+91 93373 19419</a>
                                </div>
                            </div>
                            <a href="tel:0123456789" class="btn">Request a Free Call</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- request-area-end -->
   
     
      
   
        <!-- call-back-area -->
        <section class="call-back-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="call-back-content">
                            <div class="section-title white-title mb-10">
                                <h2 class="title">Request A Call Back</h2>
                            </div>
                            <p>Ever find yourself staring at your computer screen a good consulting slogan to come to mind? Oftentimes.</p>
                            <div class="shape">
                                <img src="assets/img/images/call_back_shape.png" alt="" data-aos="fade-right" data-aos-delay="400">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="call-back-form">
                            <form action="#">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="text" placeholder="Name *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="email" placeholder="E-mail *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="number" placeholder="Phone *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn">Send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- call-back-area-end -->
    </main>
    <!-- main-area-end -->
   <?php include 'footer.php'; ?>
   
   
   