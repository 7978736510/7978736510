 <!-- footer-area -->
    <footer>
        <div class="footer-area">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-4 col-md-6">
                            <div class="footer-widget">
                                <div class="fw-logo mb-25">
                                    <a href='index.php'><img src="assets/img/logo/logo.png" alt=""></a>
                                </div>
                                <div class="footer-content">
                                    <div class="footer-social">
                                        <ul class="list-wrap">
                                            <li><a href="https://www.facebook.com/7yardssolutionsofficials"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="https://twitter.com/7yardssolutions"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="https://www.instagram.com/7yardssolutions/"><i class="fab fa-instagram"></i></a></li>
                                            <li><a href="https://www.linkedin.com/company/7yardssolutions/?viewAsMember=true"><i class="fab fa-linkedin-in"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <div class="footer-widget">
                                <h4 class="fw-title">Information</h4>
                                <div class="footer-info-list">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-phone-call"></i>
                                            </div>
                                            <div class="content">
                                                <a href="tel:+91 93373 19419">+91 93373 19419</a>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-envelope"></i>
                                            </div>
                                            <div class="content">
                                                <a href="mailto:info@7yardssolutions.com">info@7yardssolutions.com</a>
                                            </div>
                                        </li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <div class="footer-widget">
                                <h4 class="fw-title">Quick Links</h4>
                                <div class="footer-link-list">
                                    <ul class="list-wrap">
                                       <li><a href='search-engine-optimization.php'>SEO</a></li>
                                        <li><a href='social-media-marketing.php'>SMM</a></li>
                                        <li><a href='social-media-optimization.php'>SMO</a></li>
                                        <li><a href='website-design.php'>Webdesign</a></li>
                                        <li><a href='graphic-design.php'>Graphic Design</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 col-md-6">
                             <div class="footer-widget">
                                <h4 class="fw-title">Registered Address</h4>
                                <div class="footer-instagram">
                                 Plot No N6/263,Prashant Bhawan,
Kalyan Mandap Lane, Nayapalli Sub Post Office, Nayapalli, Bhubaneswar, Khordha, Odisha, 751012
                                </div>
                            </div>
                             <div class="footer-widget">
                                <h4 class="fw-title">Office Address</h4>
                                <div class="footer-instagram">
                                    Plot N2-145 (Annex), IRC Village, Nayapalli, Bhubaneswar 751015
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-7 order-0 order-lg-2">
                            <div class="footer-newsletter">
                                <h4 class="title">Newsletter SignUp!</h4>
                                <form action="#">
                                    <input type="text" placeholder="e-mail Type . . .">
                                    <button class="btn btn-two" type="submit">Subscribe</button>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="copyright-text">
                                <p>Copyright © <a href='index.php'>7YardsSolution</a> | All Right Reserved</p>
                                <a href='contact.php'>Support Terms & Conditions Privacy Policy.</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-shape">
                <img src="assets/img/images/footer_shape01.png" alt="" data-aos="fade-right" data-aos-delay="400">
                <img src="assets/img/images/footer_shape02.png" alt="" data-aos="fade-left" data-aos-delay="400">
                <img src="assets/img/images/footer_shape03.png" alt="" data-parallax='{"x" : 100 , "y" : -100 }'>
            </div>
        </div>
    </footer>
    <!-- footer-area-end -->
    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.odometer.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/gsap.js"></script>
    <script src="assets/js/ScrollTrigger.js"></script>
    <script src="assets/js/SplitText.js"></script>
    <script src="assets/js/gsap-animation.js"></script>
    <script src="assets/js/jquery.parallaxScroll.min.js"></script>
    <script src="assets/js/swiper-bundle.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
    
     <script>
     document.addEventListener('contextmenu', (e) => e.preventDefault());

 function ctrlShiftKey(e, keyCode) {
   return e.ctrlKey && e.shiftKey && e.keyCode === keyCode.charCodeAt(0);
 }

 document.onkeydown = (e) => {
    Disable F12, Ctrl + Shift + I, Ctrl + Shift + J, Ctrl + U
   if (
     event.keyCode === 123 ||
     ctrlShiftKey(e, 'I') ||
     ctrlShiftKey(e, 'J') ||
     ctrlShiftKey(e, 'C') ||
     (e.ctrlKey && e.keyCode === 'U'.charCodeAt(0))
   )
     return false;
 };
 </script>
</body>

</html>