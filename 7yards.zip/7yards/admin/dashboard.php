<?php
session_start();
include "connection/config.php";

if(!isset($_SESSION["Login"])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    
      <title>7yards Solution</title>
  <link rel="icon" href="../img/logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="icon" href="images/graduation.png" type="image/png">
	<meta name="theme-color" content="#6d7ffd">
   <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

   <style>

    .card .card-body{
      height: 200px   !important;
    }
 
    </style>

  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
   <?php include "header.php"; ?>
    <!-- Sidebar menu-->
     <?php include "sidebar.php" ?>
    <main class="app-content" style=" background-image: url(images/2.webp) !important;">
      <div class="app-title">
       
          <h1>&nbsp;&nbsp;&nbsp;<b> 7Yards Solution Admin Dashboard</b></h1>
          <!--<p>A free and open source Bootstrap 4 admin template</p>-->
          
          <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item" ><a style="color: #2c81bb;" href="">Dashboard</a></li>
          </ul>
      </div>
      
      <div class="container" >
        
        <div class="row">

     

      
     
 </div> 
           
     </div>
    </main>


    
      
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="js/plugins/chart.js"></script>
   
  </body>
</html>