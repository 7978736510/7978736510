<?php
session_start();
include "connection/config.php";
session_destroy();
header("location:index.php");
?>