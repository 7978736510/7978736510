<?php
   include "connection/config.php";

   if(isset($_POST['submit'])){

   $title = $_POST['title'];
   $category = $_POST['category'];

         $img = $_FILES['img']['name'];
				 if($img=="")
				 {
					$a=$img;
				 }
				 else
				 {
				 $f_tmp = $_FILES['img']['tmp_name'];
				 $f_details=pathinfo($_FILES['img']['name']);
				 $f_ext=strtolower($f_details['extension']);
				 $f_dynamicname=date('dmYHis').rand(100,1000);
				 $fuploadednm="Pic_".$f_dynamicname.".".$f_ext;
 				 if($f_ext=='jpg' || $f_ext=='png' || $f_ext=='jpeg' || $f_ext=='JPG')
				{
				$m=move_uploaded_file($f_tmp, "photo/".$fuploadednm);
				// $m=compressImage($f_tmp, "photo/".$fuploadednm,40);
				 }
				$a=$fuploadednm;
				 }

			$insert = $mysqli->query("INSERT INTO `gallery` (`title`,`category`,`img`) VALUES ('$title','$category','$a')");

	
		
		if($insert){
	echo ("<script LANGUAGE='JavaScript'>window.alert('Successully Uploaded');
								    window.location.href='gallery-view.php';
						    		</script>");
	
	
}
else{
	
echo ("<script LANGUAGE='JavaScript'>window.alert( Upload failed');
								   window.location.href='gallery.php';
						    		</script>");
}

}




function compressImage($source, $destination, $quality) {

   $info = getimagesize($source);

  if ($info['mime'] == 'image/jpeg') 
    $image = imagecreatefromjpeg($source);
  elseif ($info['mime'] == 'image/gif') 
    $image = imagecreatefromgif($source);
  elseif ($info['mime'] == 'image/png') 
    $image = imagecreatefrompng($source);
	elseif ($info['mime'] == 'image/JPG') 
    $image = imagecreatefrompng($source);
	elseif ($info['mime'] == 'image/pdf') 
    $image = imagecreatefrompng($source);
	elseif ($info['mime'] == 'image/doc') 
    $image = imagecreatefrompng($source);
	elseif ($info['mime'] == 'image/docx') 
    $image = imagecreatefrompng($source);

    imagejpeg($image, $destination, $quality);

}




$id=$_GET['id'];

$delete=$mysqli->query("delete from gallery where id='$id' ");
if($delete){
	
	  
echo ("<script LANGUAGE='JavaScript'>window.alert(' Delete Successfully');
								    window.location.href='gallery-view.php';
						    		</script>");
	
	
}
else{
	
echo ("<script LANGUAGE='JavaScript'>window.alert(' Delete Failed');
								     window.location.href='gallery.php';
						    		</script>");
}


?>