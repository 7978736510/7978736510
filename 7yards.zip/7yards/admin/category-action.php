<?php
session_start();
include "connection/config.php";

if(!isset($_SESSION["Login"])){
	header("location:index.php");
}

if(isset($_POST['submit'])){
$name = $_POST['name'];



      $insert = $mysqli->query("INSERT INTO `category`(`name`) VALUES ('$name')");


     if($insert){
	echo ("<script LANGUAGE='JavaScript'>window.alert('Registered Successully');
								    window.location.href='category-view.php';
						    		</script>");
	
	
}
else{
	
echo ("<script LANGUAGE='JavaScript'>window.alert('Registered failed');
								   window.location.href='category.php';
						    		</script>");
}

	}



$id=$_GET['id'];

$delete=$mysqli->query("DELETE FROM `category` WHERE id='$id' ");
if($delete){
	
	  
echo ("<script LANGUAGE='JavaScript'>window.alert('Insurance Delete Successfully');
								    window.location.href='category-view.php';
						    		</script>");
	
	
}
else{
	
echo ("<script LANGUAGE='JavaScript'>window.alert('insurance Delete Failed');
								     window.location.href='category-view.php';
						    		</script>");
}	

?>