
<style>
   div.dataTables_wrapper div.dataTables_length label {
    text-transform: capitalize;
}
</style>


<header class="app-header" style=" background-color:#002944;">
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle"  data-toggle="sidebar" aria-label="Hide Sidebar" style="color:#fff"></a>
     &nbsp;<p style="color:#fff;font-size:20px;margin-top:6px">7Yards Solution</p>
      <ul class="app-nav">
       
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg" ></i>&nbsp;Admin</a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
          <!--   <li><a class="dropdown-item" href="changeusername.php">Change User Name</a></li>	-->	
          <li><a class="dropdown-item" href="changepassword.php">Change Password</a></li> 
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>