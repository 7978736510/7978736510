<?php
//error_reporting(0);
$mysqli = new mysqli("localhost", "u246090563_7YSAdmin", "7Yardssolutions@123", "u246090563_DBYards");
/* check connection */
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}
/* if(!isset($_SESSION)){
   session_start();
} */
?>