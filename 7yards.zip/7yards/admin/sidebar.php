<style>
 table.dataTable thead > tr > th.sorting_asc, table.dataTable thead > tr > th.sorting_desc, table.dataTable thead > tr > th.sorting, table.dataTable thead > tr > td.sorting_asc, table.dataTable thead > tr > td.sorting_desc, table.dataTable thead > tr > td.sorting {
    padding-right: 30px;
    font-size: 14px;
    color: #0f64a1;
    text-transform: uppercase;
}
.app-sidebar {
position: fixed;
top: 0;
bottom: 0;
left: 0;
padding-top: 70px;
width: 230px;
overflow: auto;
z-index: 10;
background-color: #024478;

}
.app-sidebar__toggle:focus, .app-sidebar__toggle:hover{
background-color: #024478;
}
.app-menu__item:hover {
background: #000 !important;
}
.app-content {
min-height: calc(100vh - 50px);



}
.treeview.is-expanded [data-toggle='treeview'] {
/* border-left-color: #009688; */
border-left-color: #000;
background: #024478;
} 
.app-menu__item:focus{
background: #000;
}
.app-menu__item.active{
background: #000;
border-left-color: #000;
}
.treeview-menu {
max-height: 0;
overflow: hidden;
-webkit-transition: max-height 0.3s ease;
-o-transition: max-height 0.3s ease;
transition: max-height 0.3s ease;
background: #000;

}
aside ul li{
border-top: solid #000 1px;
box-shadow: 0 5px 35px -18px #000;
}
.app-sidebar{
  background-image: url(images/12.jpg) !important;
}
.app-header{
  background-image: url(images/1.webp) !important;
}

</style>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
 
      <p class="app-sidebar__user-name"></p>
      
    </div>
  </div>
  <ul class="app-menu">
    <li><a class="app-menu__item " style="background-color:#ff9800; margin-bottom: 5px; " href="dashboard.php"><i class="app-menu__icon fa fa-dashboard" ></i><span class="app-menu__label"><b> Dashboard</b></span></a></li> 

 <li><a class="app-menu__item " style="background-color:#ff9800; margin-bottom: 5px; " href="contact.php"><i class="app-menu__icon fa fa-dashboard" ></i><span class="app-menu__label"><b> Contact</b></span></a></li> 
 
 <li class="treeview"><a class="app-menu__item" style="background-color:#ffc107; margin-bottom: 5px;" href="" data-toggle="treeview"><i class="fa fa-tasks" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;<span class="app-menu__label"><b> Category</b></span> <i class="treeview-indicator fa fa-angle-right"> </i></a>
      <ul class="treeview-menu">
       
         <li><a class="treeview-item"  href="category.php"><i class="icon fa fa-arrow-circle-o-right" aria-hidden="true"></i>Add</a></li>
          <li><a class="treeview-item" href="category-view.php"><i class="icon fa fa-arrow-circle-o-right" aria-hidden="true"></i>  View</a></li>
           </ul>
         </li> 
         <li class="treeview"><a class="app-menu__item" style="background-color:#ffc107; margin-bottom: 5px;" href="" data-toggle="treeview"><i class="fa fa-tasks" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;<span class="app-menu__label"><b> Gallery</b></span> <i class="treeview-indicator fa fa-angle-right"> </i></a>
      <ul class="treeview-menu">
       
         <li><a class="treeview-item"  href="gallery.php"><i class="icon fa fa-arrow-circle-o-right" aria-hidden="true"></i>Add</a></li>
          <li><a class="treeview-item" href="gallery-view.php"><i class="icon fa fa-arrow-circle-o-right" aria-hidden="true"></i>  View</a></li>
           </ul>
         </li> 
     
 </ul>
</aside>





 