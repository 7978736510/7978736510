<?php
session_start();
include "connection/config.php";

if(!isset($_SESSION["Login"])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="">
    <!-- Twitter meta-->
     <meta property="twitter:card" content="">
    <meta property="twitter:site" content="">
    <meta property="twitter:creator" content="">
    <!-- Open Graph Meta-->
     <meta property="og:type" content="">
    <meta property="og:site_name" content="">
    <meta property="og:title" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <meta property="og:description" content="">
    <title>Gallery-7yards solution</title>
  <link rel="icon" href="../img/logo.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
  <style>
      #imagePreview img{
        height: 100px; width: 100px;
      }
       #imagePreview1 img{
         height: 100px; width: 100px;
      }
       #imagePreview2 img{
         height: 100px; width: 100px;
      }
       #imagePreview3 img{
          height: 100px; width: 100px;
      }
       #imagePreview4 img{
         height: 100px; width: 100px;
      }
    </style>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <?php include "header.php"; ?>
    <!-- Sidebar menu-->
     <?php include "sidebar.php" ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Gallery Add</h1>
         
        </div>
      
      </div>
      <div class="row">
	  <div class="col-md-12">
          <div class="tile">
	
     <div class="container">
  <div class="row">


    <div class="col-md-2 col-lg-2 col-sm-2"></div>


    <div class="col-md-7 col-lg-7 col-sm-7">
                      <form action="gallery-action.php" method="post" enctype="multipart/form-data">
  <div class="mb-3 mt-3">
    <label for="name" class="form-label">Title:</label>
    <input type="text" class="form-control" placeholder="title" name="title">
  </div>
  <div class="mb-3 mt-3"> 
     <label for="sel1" class="form-label">Select Category Name:</label>
  <select class="form-control" name="category" id="">
      <option>Select</option>
      <?php
      $select6=$mysqli->query("SELECT * FROM `category`");
      while($row6=$select6->fetch_assoc()){
      ?>
      <option value="<?php echo $row6['name']; ?>"><?php echo $row6['name']; ?></option>
  <?php } ?>
     
    </select>
  </div>

     <div class="mb-3 mt-3">
      <label for="comment">Upload File(Image size : 395px x 405px):</label>
      <input type="file" id="myFile" name="img">
    </div>

    
<button type="submit" class="btn btn-primary" name="submit">Submit</button>


  </form>  
</div>
<div class="col-md-3 col-lg-3 col-sm-3"></div>

            
          </div>
		  </div>
       
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == '') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
	<script>
    function fileValidation() {
      var fileInput =
        document.getElementById('file');
      
      var filePath = fileInput.value;
    
      // Allowing file type
      var allowedExtensions =
          /(\.jpg|\.jpeg|\.png|\.gif)$/i;
      
      if (!allowedExtensions.exec(filePath)) {
        alert('Invalid file type');
        fileInput.value = '';
        return false;
      }
      else
      {
      
        // Image preview
        if (fileInput.files && fileInput.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            document.getElementById(
              'imagePreview').innerHTML =
              '<img src="' + e.target.result
              + '"/>';

          };
          
          reader.readAsDataURL(fileInput.files[0]);
        }
         
      }
    }
  </script>
  <script>
    function fileValidation1() {
      var fileInput =
        document.getElementById('file1');
      
      var filePath = fileInput.value;
    
      // Allowing file type
      var allowedExtensions =
          /(\.jpg|\.jpeg|\.png|\.gif)$/i;
      
      if (!allowedExtensions.exec(filePath)) {
        alert('Invalid file type');
        fileInput1.value = '';
        return false;
      }
      else
      {
      
        // Image preview
        if (fileInput.files && fileInput.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            document.getElementById(
              'imagePreview1').innerHTML =
              '<img src="' + e.target.result
              + '"/>';

          };
          
          reader.readAsDataURL(fileInput.files[0]);
        }
         
      }
    }
  </script>
  <script>
    function fileValidation2() {
      var fileInput =
        document.getElementById('file2');
      
      var filePath = fileInput.value;
    
      // Allowing file type
      var allowedExtensions =
          /(\.jpg|\.jpeg|\.png|\.gif)$/i;
      
      if (!allowedExtensions.exec(filePath)) {
        alert('Invalid file type');
        fileInput1.value = '';
        return false;
      }
      else
      {
      
        // Image preview
        if (fileInput.files && fileInput.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            document.getElementById(
              'imagePreview2').innerHTML =
              '<img src="' + e.target.result
              + '"/>';

          };
          
          reader.readAsDataURL(fileInput.files[0]);
        }
         
      }
    }
  </script>
  <script>
    function fileValidation3() {
      var fileInput =
        document.getElementById('file3');
      
      var filePath = fileInput.value;
    
      // Allowing file type
      var allowedExtensions =
          /(\.jpg|\.jpeg|\.png|\.gif)$/i;
      
      if (!allowedExtensions.exec(filePath)) {
        alert('Invalid file type');
        fileInput1.value = '';
        return false;
      }
      else
      {
      
        // Image preview
        if (fileInput.files && fileInput.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            document.getElementById(
              'imagePreview3').innerHTML =
              '<img src="' + e.target.result
              + '"/>';

          };
          
          reader.readAsDataURL(fileInput.files[0]);
        }
         
      }
    }
  </script>
  <script>
    function fileValidation4() {
      var fileInput =
        document.getElementById('file4');
      
      var filePath = fileInput.value;
    
      // Allowing file type
      var allowedExtensions =
          /(\.jpg|\.jpeg|\.png|\.gif)$/i;
      
      if (!allowedExtensions.exec(filePath)) {
        alert('Invalid file type');
        fileInput1.value = '';
        return false;
      }
      else
      {
      
        // Image preview
        if (fileInput.files && fileInput.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            document.getElementById(
              'imagePreview4').innerHTML =
              '<img src="' + e.target.result
              + '"/>';

          };
          
          reader.readAsDataURL(fileInput.files[0]);
        }
         
      }
    }
  </script>
 <script type="text/javascript">
    $(document).ready(function () {
            $('#cat_id').on('change', function () {
                var ctid = $(this).val(); //alert(ctid);
                if (ctid) {
                    $.ajax({
                        type: 'POST',
                        url: 'item_ajax.php',
                        data: 'cctid=' + ctid,
                        success: function (html) {
                            $('#name').html(html);//alert(cctid);
                        }
                    });
                } else {
                    $('#name').html('<option value="">Choose Product Name</option>');
                }
            });
        });
      </script>
</body>

</html>