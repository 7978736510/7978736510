



<?php
session_start();
include "connection/config.php";

if(!isset($_SESSION["Login"])){
    header("location:index.php");
}

if(isset($_POST['contact_submit'])){

$name = $_POST['name'];
$mno = $_POST['mno'];
$email = $_POST['email'];

$message = $_POST['message'];


        $insert = $mysqli->query("insert into contact (`name`, `mno`,`email`,`message`) VALUES ('$name','$mno',$email',$message')");






if($insert){
    ini_set( 'display_errors', 1 );
error_reporting( E_ALL );
$from = "subhashreesethi814@gmail.com";
$to = "info@7yardssolutions.com";
$subject = "Checking PHP mail";
$message1 = "$message";
$headers = "From:" . $from;
if(mail($to,$subject,$message1, $headers)) {
    echo "The email message was sent.";
} else {
    echo "The email message was not sent.";
}
 
     echo ("<script LANGUAGE='JavaScript'>window.alert('Registered Successully');
                                    window.location.href='contact.php';
                                    </script>");
    
}else{

echo ("<script LANGUAGE='JavaScript'>window.alert('Registered failed');
                                   window.location.href='contact.php';
                                    </script>");
    
}
   
    
    
}




    

$id=$_GET['id'];

$delete=$mysqli->query("delete from contact where id='$id' ");
if($delete){
    
      
echo ("<script LANGUAGE='JavaScript'>window.alert('Delete Successfully');
                                    window.location.href='contact.php';
                                    </script>");
    
    
}
else{
    
echo ("<script LANGUAGE='JavaScript'>window.alert(' Delete Failed');
                                     window.location.href='contact.php';
                                    </script>");
}
    

?>

