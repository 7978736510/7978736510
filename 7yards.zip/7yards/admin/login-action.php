<?php
session_start();
include "connection/config.php";
if(isset($_POST['login'])){
	$username=$mysqli->real_escape_string($_POST['username']);
	$password=$mysqli->real_escape_string($_POST['password']);
	
	$query=$mysqli->query("select * from admin where username='".($username)."' and password='".($password)."'");
	
	if($query->num_rows>0)
	{
		$_SESSION['Login']="$username";
		header("location:dashboard.php");
	}
	else
	{
	  
		echo ("<script LANGUAGE='JavaScript'>window.alert('Invalid UserName Or Password');
								    window.location.href='index.php';
						    		</script>");
	}
}
?>

