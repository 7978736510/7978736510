<?php 
include'connection/config.php';
if (isset($_POST['contact_submit'])) {
	$name=$_POST['name'];
	$mno=$_POST['mno'];
	$email=$_POST['email'];
	$message=$_POST['message'];

// echo "INSERT INTO `contact` (`name`,`mno`,`email`,`message`) VALUES ('$name',`mno`,'$email','$message')";

	$insert_faq=$mysqli->query("INSERT INTO `contact` (`name`,`mno`,`email`,`message`) VALUES ('$name','$mno','$email','$message')");
	
	     	    if($insert_faq){
        $to = "info@7yardssolutions.com";
                    $from=$email;
                    $subject="Contact";
                    $body = "Name: $name \r\n<br/> Phone no: $mno \r\n<br/> Email: $email \r\n<br/> Course: $course \r\n<br/> Subject: $subject \r\n<br/> Message:$message ";

                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
                    $headers .= "From:".$from."";

                    if(mail($to, $subject, $body, $headers))
                    {
                        header("location:contact.php");
                    }
                    else {
                        echo 'fail';
                    }

    }
    else{
	
echo ("<script LANGUAGE='JavaScript'>window.alert('Registered failed');
								   window.location.href='contact.php';
						    		</script>");
}

}



?>