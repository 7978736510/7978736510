-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 26, 2024 at 10:02 AM
-- Server version: 10.11.8-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u246090563_DBYards`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(8, 'Festival ss');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mno` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `mno`, `email`, `message`) VALUES
(22, 'subhashree sethi', '7978736510', 'subhashreesethi256@gmail.com', 'I want to know about digital marketing.'),
(23, 'subhashree', '7978736510', 'subhashreesethi256@gmail.com', 'HIi,\r\nI want to know about digital marketing.'),
(24, 'Siptirekha Bai', '9337651290', 'siptirekhab@gmail.com', 'Hiring'),
(25, 'subhashree', '7978736510', 'subhashreesethi256@gmail.com', 'HIi,\r\nI want to know about digital marketing.'),
(26, 'Siptirekha Bai', '9337651290', 'siptirekhab@gmail.com', 'hii'),
(27, 'PALMER LOTTIE', '2704987769', 'palmerlottie9@outlook.com', 'I need your service for a graphic design project.'),
(28, 'PALMER LOTTIE', '2704987769', 'palmerlottie9@outlook.com', 'I need your service for a graphic design project.'),
(29, 'PALMER LOTTIE', '2704987769', 'palmerlottie9@outlook.com', 'I need your service for a graphic design project.'),
(30, 'PALMER LOTTIE', '2704987769', 'palmerlottie9@outlook.com', 'I need your service for a graphic design project.'),
(31, 'Christin', '06-7548886', 'christin.whittemore@gmail.com', 'Hi!\r\n\r\nIt is with sad regret to inform you that LeadsFly is shutting down!\r\n\r\nWe have made available all our consumer and business leads for the entire world on our way out.\r\n\r\nWe have the following available worldwide:\r\n\r\nConsumer Records: 294,582,351\r\nBusiness Records: 25,215,278\r\n\r\nVisit us here: https://leadsfly.biz/7yardssolutions.com/\r\n\r\nBest regards,\r\nChristin'),
(32, 'Keylee Jones', '7081484466', 'Keyleejones440@outlook.com', 'Would you be available to help our company with Branding '),
(33, 'Keylee Jones', '7081484466', 'Keyleejones440@outlook.com', 'Would you be available to help our company with Branding '),
(34, 'Stephanie Squadrito', '0741187132', 'stephanie@bedthreads-ua.com', 'Bed Threads Crafted from the finest French linen, we would like to extend to you an invitation to co-market our new product lines. Please contact for more details: stephanie@bedthreads-ua.com or Skype: +44 7411871326'),
(35, 'Mohit Tiwari', '9979553686', 'surekashristi8@gmail.com', 'Hello,\r\n\r\nI hope you are doing well.\r\n\r\nSinelogix Technology Pvt. Ltd is a Website Design and Development company based out in India. We are working into web development from last 10 years supporting on various kind of technologies like Magento, WordPress, Laravel, Codeigniter, PHP, HTML etc.\r\n\r\nHere is our cost:\r\n\r\n1. Sr.PHP developer with 3-5 years of experience : 60000 INR per month\r\n2. Sr. Laravel developer with more than 3-5 years of experience : 65000 INR per month\r\n3. Sr. WordPress/Woo-Commerce developer with 3-5 years of experience: 55000 INR per month\r\n4. Magento developer with 3-5 years of experience: 65000 INR per month\r\n5. Android Developer : 1,20,000 INR per month\r\n6. React Developer  : 90000 INR per month.\r\n7. Flutter Developer : 1,30,000 INR Per Month\r\n8. IOS Developer with 2-3 Years of Experience : 90000 INR per month\r\n9. SEO Engineer with 3-5 Years of Experience : 35000 INR per month.\r\n10. QA Software Tester with 3-5 Years of Experience : 65000 INR Per Month\r\n11.Shopify Developer: 3-5 years of experience: 70000 INR/Month\r\n12.Java developer with 3+ Years of experience: 1,60,000 INR/per month.\r\n\r\nOur Payment Term:\r\nThere is no advance payment, we can sign monthly contracts and you can pay every month end.\r\n\r\nIf you are looking for any help please email me at mohit.tiwari@sinelogixtechnologies.com or whatsapp me at +91 8980898451 / +91 9979553686\r\nOur Skype id is: itsdennismiller.'),
(36, 'Daria Tanka', '8185386234', 'marketing@audio-technica-india.com', '\"\r\nHi,\r\n\r\nI represent Audio-Technica, a leading brand in the design and manufacture of high-quality audio equipment. We are currently seeking a strategic partner who can leverage the power of social media platforms to enhance our brand presence and drive consumer engagement in India.\r\n\r\nYou can find more detailed information about our brand on our: Facebook page: https://www.facebook.com/audiotechnica.in - Website: https://www.audio-technica.co.in/\r\nWe are committed to offering competitive compensation, ample resources, and the necessary support to ensure the success of our partnership.\r\n\r\nWe are excited about the possibility of working together and eager to explore how we can collaborate to create compelling and effective digital marketing campaigns that resonate with consumers in India.\r\n\r\nIf you are interested in this opportunity, please respond to us via email to discuss further collaboration.\r\nBest regards.\r\n\r\nDaria\r\nMarketing Director\r\nAudio-Technica.\"'),
(37, 'CompanyRegistar.com', '5231428460', 'jervois.imogene83@hotmail.com', 'Hi\r\n\r\nThis will greatly impact your page rank, the more increased directories your company is listed \r\n\r\nin, globally or locally, the greater your back links you have and the higher you rank in Bing - Yahoo - \r\n\r\nGoogle.\r\n\r\nNever has it been simpler to promote your online property\r\n\r\nJust a few inputs and our system willl do the rest. No more struggling about CAPTCHAs - email \r\n\r\nverification or manual link building.\r\n\r\nWe have automed everything that we could have to make submitting your online property a \r\n\r\nbreeze.\r\n\r\nSee your online property on the first page.\r\n\r\nWe will list your site to numerous directories and give you a detailed \r\n\r\nreport on the status of each submission. Although we have created an automated system to \r\n\r\na large extent, some of the listings may require manual approval which could cause a slight \r\n\r\ndelay.\r\n\r\nMaking your life simpler\r\n\r\nCompanyRegistar.com'),
(38, 'Dominik Dey', '89686881', 'dominik.dey@gmail.com', 'A local store or a multinational chain, we build mobile Apps at crazy prices. We convert your website into an App.\r\n\r\nAndroid ($50)\r\niOS ($50)\r\n\r\nGet your free consultation here:\r\n\r\nhttps://forms.gle/hbayvMrG3N7u2Rbu9'),
(39, 'Ginger Keyes', '97006128', 'keyes.ginger@outlook.com', 'Hi,\r\n\r\nThis is crazy, we are building mobile Apps for $50.\r\n\r\nGet your iOS and Android App!\r\n\r\nWhy are we doing this? Well, we are building a lot for cheap.\r\n\r\nVisit us PCXLeads.com'),
(40, 'LeslieLal', '', 'mikhaileliffkt@mail.ru', '??? ????? ? ??????? ? ?????? \r\n \r\n?????? ?????? ?????? ??????, ??????????, ???????? ?????????? ??????? ??????. ????? ??????????? ???????? ? ????? ?????? ???????, ? ???????????? ???????? ????? ?????? ?????????? ???????????? ? ?????????????. ?? ?????? ? ??? ????????????? ??????????? ?????? ? ???? ?? ??????, ???????? ????? ?????????? ?? ?????  ???????????????? ???? ??????, ????? ??????? ??? ????? ??????? ?????? ????? ?? ?????? ????? ? ????????. \r\n \r\nSource: \r\n \r\n<a href=https://moscowneversleep.com/>??? ????? ? ??????? ? ??????</a> \r\n'),
(41, 'MichaelEveks', 'Accstores.', 'valliewaltman@icloud.com', 'Welcome to https://Accstores.com, where accessibility meets innovation. Our platform provides cutting-edge tools and services to ensure every website is inclusive and user-friendly. Join us in our mission to make the web accessible to everyone. Explore https://Accstores.com today and elevate your online presence. \r\n \r\n \r\nclick The Up Coming Website Page \r\nhttps://Accstores.com'),
(42, 'MichaelEveks', 'Accstores.', 'omerbirkbeck7896@icloud.com', 'Welcome to https://Accstores.com, where accessibility meets innovation. Our platform provides cutting-edge tools and services to ensure every website is inclusive and user-friendly. Join us in our mission to make the web accessible to everyone. Explore https://Accstores.com today and elevate your online presence. \r\n \r\n \r\njust Click  \r\nhttps://Accstores.com'),
(43, 'Lynwood Duval', '7016829094', 'lynwood.duval@gmail.com', 'Hi,\r\n\r\nI hope this email finds you well.\r\n\r\nMy name is Michael, and I’m reaching out to introduce you to an incredible opportunity to elevate your digital marketing skills and start earning from day one with Digital Wealth Academy (DWA).\r\n\r\nAre you struggling to find a reliable way to make money online? Many people face the same challenge, feeling overwhelmed by the sheer volume of information and the steep learning curve. That’s where DWA comes in.\r\n\r\nWhy Digital Wealth Academy?\r\n- Comprehensive Training: From SEO and social media marketing to email campaigns and sales funnels, DWA covers it all.\r\n- Master Resell Rights (MRR): Gain the right to resell our top-tier course and keep 100% of the profits.\r\n- Proven Success: Our members have transformed their lives, achieving financial freedom through our program.\r\n\r\nWhat Our Students Are Saying:\r\n\r\n“DWA has been a game-changer for me! Within three months, I went from zero to making a consistent $5,000 per month. The training modules are thorough and easy to follow.” – Sarah J.\r\n\r\n“Thanks to Digital Wealth Academy, I was able to quit my 9-to-5 job and focus entirely on my online business. The support and resources provided are unparalleled.” – Mike T.\r\n\r\n“The Master Resell Rights model is brilliant! It allowed me to start earning right away without having to create my own products from scratch.” – Rachel K.\r\n\r\nDon’t just take my word for it. See how DWA can change your life by visiting https://digitalwealthacademy.online/.\r\n\r\nReady to Get Started?\r\n\r\nClick https://digitalwealthacademy.online/ to learn more and take the first step towards financial independence.\r\n\r\nIf you have any questions or need further information, feel free to reply to this email. I’m here to help!\r\n\r\nBest regards,\r\n\r\nMichael'),
(44, 'Luis Alves', '8313485718', 'intl.law7@aol.com', 'Greeting. \r\nI hope this message will interest you, giving the unconventional opportunity it conveys. \r\nI’m a Private Investment Consultant sourcing and connecting business managers with Capitalists. \r\nI’m mandated by an Offshore Investment Company acting as proxy for Wealthy Oligarchs. \r\nIf you have a viable business seeking for quick Loan or Funding Partners, I have a rare opportunity for you. \r\nPlease reach out to me, through this following email  alveslus011@gmail.com if you need further details about the funding scheme. \r\nIgnore if not interested. \r\nRegards, \r\nLuis Alves \r\nLegal | Consultant | Contractor. \r\nE-mail: alveslus011@gmail.com'),
(45, 'Tory Drake', '890158953', 'tory.drake@gmail.com', 'Want Free business data?\r\n\r\nUsage:\r\n\r\nhttps://leadsbox.biz?query=YourQuery\r\n\r\n(Lawyers in New york for example)\r\n\r\n71 Million business records in 202 countries\r\n\r\nUpdated Daily\r\n\r\nCompany Name\r\ncountryCode\r\ncountryName\r\nstate\r\ncounty\r\ncity\r\nstreet\r\npostalCode\r\nbuilding\r\nlat\r\nlng\r\nCategory\r\nSecondary Category\r\nPersonal contacts\r\nPhones\r\nFax\r\nEmails\r\nReviews\r\nopening hours\r\n\r\nand more\r\n\r\nLeadsBox.biz'),
(46, 'Porter Sena', '(02) 6723 ', 'porter.sena@gmail.com', 'Are you still looking at getting your website done/ completed? Contact e.solus@gmail.com'),
(47, 'Dave Colls', '4182828303', 'colls.dave@gmail.com', 'Hey,\r\n\r\nDo you need data for marketing purposes, seeking new employment, seeking suppliers or other companies to do business with?\r\n\r\nWe have 25 million active companies across all 200 countries in an excel sheet available for you for $1 once off today.\r\n\r\nCome look at our samples!\r\n\r\nhttps://marketingbox.biz/'),
(48, 'CompanyRegistar.org', '240794066', 'curtis.waylen@googlemail.com', 'Hi \r\n\r\nI see your website is only listed in 41 out of 2459 directories\r\n\r\nThis will severely impact your page rank, the higher amount of directories your company is listed in, globally or locally, the more back links you have and the higher you rank in Bing, Yahoo, Google. \r\n\r\nIt has never been simpler to promote your website 7yardssolutions.com\r\n\r\nJust a few inputs and our software willl do the rest. \r\n\r\nNo more struggling about manual link building, email verification or CAPTHCAs.\r\n\r\nWe have automed everything that we could have to make submitting your domain a breeze.\r\n\r\nSee your website on the first page.\r\n\r\nWe will list your site to thousands of directories and give you a full report on the status of each listing. Although we have created an automated system to a large extent, some of the listings may require manual approval which could cause a slight delay. \r\n\r\nMaking your life easier \r\n\r\nhttps://CompanyRegistar.org'),
(49, 'AmandaAquart2', '8928923315', 'amandaKejerwaya@gmail.com', 'Hey darling, want to hang out? -  https://is.gd/2xVU7z?vek'),
(50, 'AmandaAquart3', '8444132833', 'amandaKejerwayc@gmail.com', 'Hey darling, want to hang out? -  https://rb.gy/7rnhss?Hodserne'),
(51, '????-nus', '8892435543', 'dr-klen@mail.ru', '????? ???????? ??? ?? ? ????, ?? ????? ????. ???? ??????? ???????, ??????? ????????? ???????????, ??????????? ????.?? ????????? ????????? ?????????? ????????? ? ??????? ???? ?????????? <a href=>?????? ?????????</a>, ????? ?? ????????????? ? ????? ????? ???????? ??????. ????? ????? ??? ????? ???????????? ????? ? ?????????? ?????????? ??? ????? ??? ???? ?? ???????? ? ??????? \r\n'),
(52, 'AmandaAquart3', '8138176735', 'amandaKejerway1@gmail.com', 'Hey darling, want to hang out? -  https://rb.gy/7rnhss?Hodserne'),
(53, 'RobertAboxy', '8581376245', 'yasen.krasen.13+73699@mail.ru', 'Ofedkwdkjwkjdkwjdkjw jdwidjwijdwfw fjdkqwasqfoewofjewof ojqwejfqwkdokjwofjewofjewoi 7yardssolutions.com'),
(54, 'Danial Pettis', '7148383607', 'danial.pettis@gmail.com', 'Hello,\r\n\r\nIt is with sad regret that after 12 years, LeadsMax.biz is shutting down.\r\n\r\nWe have made all our databases available on our website.\r\n\r\n25 Million companies\r\n527 Million People\r\n\r\nLeadsMax.biz'),
(55, 'AmandaAquartc', '8392275287', 'amandaKejerwayb@gmail.com', 'Hey darling, want to hang out? -  http://surl.li/ulebc?vek'),
(56, 'Philip Norman', '8526942897', 'philipnorman777@yahoo.com', 'Greetings \r\nI hope this mail finds you well. I am Mr Philip Norman a private Funds Manager for high net worth individuals. \r\n \r\nI hold a mandate from a Russian Client who wants his funds reinvested using 3rd party due to the current sanctions against Russians, which means all aspect of this transaction will remain confidential, we will discuss details of investment including investing in your company if it’s for expansion only. \r\n \r\nPlease note that there is no risk involved as funds are legal and currently in a Bank without encumbrances , all details will be available as soon as you indicate interest by contacting me via the email or phone number bellow to discuss this opportunity in more detail. \r\n \r\nSincerely, \r\n \r\nMr. Philip Norman \r\n \r\nEmail: philipnorman30@gmail.com'),
(57, 'AmandaAquart3', '8719456212', 'amandaKejerway3@gmail.com', 'Hey darling, want to hang out? -  http://surl.li/ulebc?vek'),
(58, 'AmandaAquartb', '8658397225', 'amandaKejerwayc@gmail.com', 'Hey darling, want to hang out? -  https://is.gd/2xVU7z?vek'),
(59, 'AmandaAquart2', '8964331866', 'amandaKejerwayb@gmail.com', 'Hey darling, want to hang out? -  https://rb.gy/7rnhss?Hodserne'),
(60, 'Williams Annunziata', '602-608-06', 'williams.annunziata@yahoo.com', 'Work From Home With This 100% FREE Training..., I Promise...You Will Never Look Back\r\n$500+ per day, TRUE -100% Free Training, go here:\r\n\r\nezwayto1000aday.com'),
(61, 'AmandaAquartc', '8222394443', 'amandaKejerwaya@gmail.com', 'Hey darling, want to hang out? -  http://surl.li/ulebc?vek'),
(62, 'AmandaAquart2', '8637515824', 'amandaKejerway3@gmail.com', 'Hey darling, want to hang out? -  https://is.gd/2xVU7z?vek'),
(63, 'AmandaAquartb', '8954699659', 'amandaKejerwaya@gmail.com', 'I’ve been naughty, want to help me with that?) -  https://rb.gy/7rnhss?Hodserne'),
(64, 'MichaelEveks', 'Accstores.', 'wendellfredericksen@icloud.com', 'Discover https://Accstores.com, the ultimate destination for seamless web accessibility solutions. We provide a comprehensive range of tools and services designed to make the internet accessible to all users, regardless of ability. Join us in our mission to create a more inclusive online experience for everyone. Explore https://Accstores.com today and unlock the power of accessibility. \r\n \r\n \r\nvisit Our Website \r\nhttps://Accstores.com');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `category`, `img`) VALUES
(4, '', 'Festival ss', 'Pic_24062024071145215.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
