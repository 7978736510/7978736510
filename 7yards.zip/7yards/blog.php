<?php include 'header.php'; ?>

    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">Blogs</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Blogs</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- blog-area -->
        <section class="blog__area">
            <div class="container">
                <div class="blog__inner-wrap">
                    <div class="row">
                        <div class="col-70">
                            <div class="blog-post-wrap">
                                <div class="row gutter-24">
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='digitalmarketing-blog-7yardssolution.php'><img src="assets/img/blog/h2_blog_post01.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Business</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                <h2 class="title"><a href='digitalmarketing-blog-7yardssolution.php'>Digital Marketing: Transforming Brands in the 21st Century with 7Yards Solutions</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='digitalmarketing-blog-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='performance-marketing-7yardssolution.php'><img src="assets/img/blog/h2_blog_post02.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Audit</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='performance-marketing-7yardssolution.php'>Boosting Brand Success: The Power of Performance Marketing with 7Yards Solutions</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='performance-marketing-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='seo-blog-7yardssolution.php'><img src="assets/img/blog/h2_blog_post03.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Investment</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='seo-blog-7yardssolution.php'>Maximizing Brand Visibility: The Power of Search Engine Optimization with 7Yards Solutions</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='seo-blog-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='website-development-blog-7yardssolution.php'><img src="assets/img/blog/h2_blog_post04.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Agency</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='website-development-blog-7yardssolution.php'>Enhancing Online Presence: 7Yards Solutions' Website Development Services</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='website-development-blog-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='ppc-blog-7yardssolution.php'><img src="assets/img/blog/h2_blog_post05.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Business</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='ppc-blog-7yardssolution.php'>Maximizing Business Growth with 7Yards Solutions' PPC Services</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='ppc-blog-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='mobileapplication-blog-7yardssolution.php'><img src="assets/img/blog/h2_blog_post06.jpg" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog.php'>Corporate</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i>May 21, 2024</li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='mobileapplication-blog-7yardssolution.php'>Elevating Customer Engagement: The Power of Mobile Application Development with 7yards Solutions</a></h2>
                                                <div class="blog-avatar">
                                                    <div class="avatar-thumb">
                                                        <img src="assets/img/blog/blog_avatar01.png" alt="">
                                                    </div>
                                                    <div class="avatar-content">
                                                        <p>By <a href='mobileapplication-blog-7yardssolution.php'>Admin</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                           
                            </div>
                        </div>
                        <div class="col-30">
                            <aside class="blog__sidebar">
                            
                                <div class="sidebar__widget">
                                    <h4 class="sidebar__widget-title">Categories</h4>
                                    <div class="sidebar__cat-list">
                                        <ul class="list-wrap">
                                           <li><a href='search-engine-optimization.php'>SEO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-marketing.php'>SMM <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-optimization.php'>SMO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='pay-per-click.php'>PPC <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='website-design.php'>Web Design <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='graphic-design.php'>Graphic Design <i class="flaticon-arrow-button"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sidebar__widget">
                                    <h4 class="sidebar__widget-title">Latest Posts</h4>
                                    <div class="sidebar__post-list">
                                        <div class="sidebar__post-item">
                                            <div class="sidebar__post-thumb">
                                                <a href='blog.php'><img src="assets/img/blog/sb_post01.jpg" alt=""></a>
                                            </div>
                                            <div class="sidebar__post-content">
                                                <h5 class="title"><a href='blog.php'>Maximizing Brand Visibility: The Power Of Search Engine Optimization With 7Yards Solutions</a></h5>
                                                <span class="date"><i class="flaticon-time"></i>Apr 15, 2024</span>
                                            </div>
                                        </div>
                                        <div class="sidebar__post-item">
                                            <div class="sidebar__post-thumb">
                                                <a href='blog.php'><img src="assets/img/blog/sb_post02.jpg" alt=""></a>
                                            </div>
                                            <div class="sidebar__post-content">
                                                <h5 class="title"><a href='blog.php'>Enhancing Online Presence: 7Yards Solutions' Website Development Services</a></h5>
                                                <span class="date"><i class="flaticon-time"></i>Apr 15, 2024</span>
                                            </div>
                                        </div>
                                        <div class="sidebar__post-item">
                                            <div class="sidebar__post-thumb">
                                                <a href='blog.php'><img src="assets/img/blog/sb_post03.jpg" alt=""></a>
                                            </div>
                                            <div class="sidebar__post-content">
                                                <h5 class="title"><a href='blog.php'>Maximizing Business Growth With 7Yards Solutions' PPC Services</a></h5>
                                                <span class="date"><i class="flaticon-time"></i>may 15, 2024</span>
                                            </div>
                                        </div>
                                   
                                    </div>
                                </div>
                             
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- blog-area-end -->
        <!-- call-back-area -->
        <section class="call-back-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="call-back-content">
                            <div class="section-title white-title mb-10">
                                <h2 class="title">Request A Call Back</h2>
                            </div>
                            <p>Ever find yourself staring at your computer screen a good consulting slogan to come to mind? Oftentimes.</p>
                            <div class="shape">
                                <img src="assets/img/images/call_back_shape.png" alt="" data-aos="fade-right" data-aos-delay="400">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="call-back-form">
                            <form action="#">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="text" placeholder="Name *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="email" placeholder="E-mail *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="number" placeholder="Phone *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn">Send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- call-back-area-end -->
    </main>
    <!-- main-area-end -->

    <?php include 'footer.php'; ?>