<?php include 'header.php'; ?>
	<meta name="description" content="Best digital marketing and Web development Company in Bhubaneswar">
	<meta name="keywords" content="Social Media Marketing , Social Media Marketing Agency , best social media marketing agency , facebook advertisement , social media advertisement , online marketing , best online marketing agency">

    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">Social Media Marketing</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Service Details</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- services-details-area -->
        <section class="services__details-area">
            <div class="container">
                <div class="services__details-wrap">
                    <div class="row">
                        <div class="col-70 order-0 order-lg-2">
                             <h2 class="title">Welcome to 7Yards Solutions - Your Partner in Social Media Success</h2>
                            <div class="services__details-thumb">
                                <img src="assets/img/services/smm1.jpg" alt="">
                            </div>
                            <div class="services__details-content services__details-content-two">
                               
                                <p>At 7Yards Solutions, we understand the power of social media in today's digital landscape. With billions of users engaging on various platforms daily, your brand's presence on social media can make all the difference. That's where we come in.</p>
                                <div class="services__details-inner-six">
                                    <div class="row gutter-24 align-items-center">
                                        <div class="col-lg-7 col-md-6">
                                            <div class="services__details-inner-content-three">
                                                <h3 class="title"></h3>
                                                <p>when an unknown printer took are galley type der one roof, thereand scrambled itter to make a type specimen bookhas a not only five centurie </p>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-6">
                                            <div class="services__details-inner-graph">
                                                <img src="assets/img/services/services_details_graph01.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <h2 class="title-two">Our Social Media Marketing (SMM) Services:</h2>
                                <p><b>Strategy Development:</b> We start by understanding your brand, target audience, and objectives. Then, we craft a tailored social media strategy to elevate your brand's presence and achieve your goals.</p>
<p><b>Content Creation:</b> Compelling content is key to capturing your audience's attention. Our team of creative minds develops engaging content that resonates with your followers and drives meaningful interactions.</p>
<p><b>Platform Management: </b> Facebook and Instagram to LinkedIn and Twitter, we manage your presence across all major social media platforms. Our experts handle everything from daily postings to community engagement, ensuring your brand stays top-of-mind.</p>
<p><b>Paid Advertising: </b> the full potential of social media with targeted advertising campaigns. We leverage advanced targeting options to reach your ideal customers and drive conversions.</p>
<p><b>Analytics and Reporting:</b> Transparency is important to us. That's why we provide detailed analytics and reports, giving you insights into your social media performance and ROI.</p>
                                <div class="services__details-inner-img-wrap">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="assets/img/services/smm2.jpg" alt="">
                                        </div>
                                        <div class="col-md-6">
                                            <img src="assets/img/services/smm3.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <h2>How We Help You Grow Revenue</h2>
                                <p><b>Increased Brand Awareness:</b> By building a strong presence on social media, we put your brand in front of a larger audience, increasing brand visibility and recognition.</p>
<p><b>Enhanced Customer Engagement:</b> Engage with your audience on a personal level. Our strategic approach fosters meaningful interactions, turning followers into loyal customers.</p>
<p><b>Lead Generation:</b> Our targeted advertising campaigns drive qualified leads to your website, helping you expand your customer base and increase sales.</p>
<p><b>Improved Conversion Rates:</b> With compelling content and targeted ads, we guide prospects through the buyer's journey, ultimately increasing conversion rates and revenue.</p>
<p><b>Competitive Advantage:</b> Stay ahead of the competition with our cutting-edge social media strategies. We continuously monitor industry trends and adjust our approach to keep you ahead of the curve.</p>
                            </div>
                        </div>
                        <div class="col-30">
                            <aside class="services__sidebar">
                                <div class="sidebar__widget">
                                    <div class="sidebar__cat-list-two">
                                        <ul class="list-wrap">
                                            <li><a href='search-engine-optimization.php'>SEO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-marketing.php'>SMM <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-optimization.php'>SMO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='pay-per-click.php'>PPC <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='website-design.php'>Web Design <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='graphic-design.php'>Graphic Design <i class="flaticon-arrow-button"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sidebar__widget sidebar__widget-two">
                                    <div class="sidebar__contact sidebar__contact-two" data-background="assets/img/services/sidebar_contact_bg.jpg">
                                        <h2 class="title">If You Need Any Help Contact With Us</h2>
                                        <a href="tel:+91 93373 19419" class="btn"><i class="flaticon-phone-call"></i>+91 93373 19419</a>
                                    </div>
                                </div>
                                <div class="sidebar__widget">
                                    <h4 class="sidebar__widget-title">Brochure</h4>
                                    <div class="sidebar__brochure">
                                        <p>when an unknown printer took ga lley offer typey anddey.</p>
                                        <a href="assets/img/services/services_details01.jpg" target="_blank" download><i class="far fa-file-pdf"></i>PDF. Download</a>
                                        <a href="assets/img/services/services_details01.jpg" target="_blank" download><i class="far fa-file-alt"></i>DOC. Download</a>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- services-details-area-end -->
        <!-- call-back-area -->
        <section class="call-back-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="call-back-content">
                            <div class="section-title white-title mb-10">
                                <h2 class="title">Request A Call Back</h2>
                            </div>
                            <p>Ever find yourself staring at your computer screen a good consulting slogan to come to mind? Oftentimes.</p>
                            <div class="shape">
                                <img src="assets/img/images/call_back_shape.png" alt="" data-aos="fade-right" data-aos-delay="400">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="call-back-form">
                            <form action="#">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="text" placeholder="Name *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="email" placeholder="E-mail *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="number" placeholder="Phone *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn">Send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- call-back-area-end -->
    </main>
    <!-- main-area-end -->

<?php include 'footer.php'; ?>
