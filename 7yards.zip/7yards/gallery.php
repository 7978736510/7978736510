
<?php include 'header.php'; ?>
<style>


.main {
  .container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-gap: 1rem;
    justify-content: center;
    align-items: center;
  }

  .card {
    color: $color-black;
    border-radius: 2px;
    background: $color-white;
    box-shadow: $box-shadow;

    &-image {
      position: relative;
      display: block;
      width: 100%;
      padding-top: 70%;
      background: $color-white;

      img {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
  }
}

@media only screen and (max-width: 600px) {
  .main {
    .container {
      display: grid;
      grid-template-columns: 1fr;
      grid-gap: 1rem;
    }
  }
}

.gallery-title h2{
        text-align: center;
}
</style>
     <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">About Us</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">About</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
    
    
           <?php 

include'connection/config.php';

            $tit_sql=$mysqli->query("SELECT * FROM `category` order by id DESC");
             $i=0;
            while($row=mysqli_fetch_array($tit_sql))
            {
               $i=$i+1;
            
           ?>
  
    <section class="gal-sec">
        <div class="gallery-title">     
        <h2><?php   echo $title= $row['name']; ?></h2>
       </div>
    <main class="main">
  <div class="container">
                <?php 

                 $name=$row['name'];
            $gallery_sql=$mysqli->query("SELECT * FROM `gallery`  WHERE category='$name'");
                $i=0;
            while($row1=mysqli_fetch_array($gallery_sql))
            {
               $i=$i+1;
           ?>
    <div class="card">
      <div class="card-image">
        <a href="admin/photo/<?php echo $row1['img'];?>" data-fancybox="gallery" data-caption="Caption Images 1">
          <img src="admin/photo/<?php echo $row1['img'];?>" alt="Image Gallery">
        </a>
      </div>
    </div>
<?php } ?>
  </div>
</main>
</section>

<?php } ?>

   </main> 
 <?php include 'footer.php'; ?>
   