<?php include 'header.php'; ?>

    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">Landing Page Design</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Service Details</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- services-details-area -->
        <section class="services__details-area">
            <div class="container">
                <div class="services__details-wrap">
                    <div class="row">
                        <div class="col-70 order-0 order-lg-2">
                             <h2 class="title">Welcome to 7Yards Solutions: Your Partner in Exceptional Landing Page Design</h2>
                            <div class="services__details-thumb">
                                <img src="assets/img/services/landing3.png" alt="">
                            </div>
                            <div class="services__details-content services__details-content-two">
                               
                                <p>At 7Yards Solutions, we understand the pivotal role that a well-crafted landing page plays in converting visitors into loyal customers. Your landing page is your digital storefront, the first impression you make on potential clients, and the gateway to successful conversions. That's why we're here to offer our expertise in crafting captivating, conversion-focused landing pages tailored to your unique brand and goals</p>

                                <div class="services__details-inner-six">
                                    <div class="row gutter-24 align-items-center">
                                        <div class="col-lg-7 col-md-6">
                                            <div class="services__details-inner-content-three">
                                                <h3 class="title">Our Business Goal</h3>
                                                <p>when an unknown printer took are galley type der one roof, thereand scrambled itter to make a type specimen bookhas a not only five centurie </p>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-6">
                                            <div class="services__details-inner-graph">
                                                <img src="assets/img/services/services_details_graph01.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <h2 class="title-two">Why Choose 7Yards Solutions for Your Landing Page Design Needs?</h2>
                                <p><b>Customized Solutions:</b> We believe in creating landing pages that reflect your brand identity and resonate with your target audience. Our team of experienced designers works closely with you to understand your vision and translate it into a visually stunning and user-friendly landing page.</p>
<p><b>Conversion Optimization:</b> Our primary goal is to help you maximize conversions. We employ proven strategies and best practices in user experience (UX) design and persuasive copywriting to ensure that your landing page not only looks great but also drives results.</p>
<p><b>Responsive Design:</b> In today's mobile-first world, having a responsive landing page is essential. We ensure that your landing page looks and functions flawlessly across all devices, providing a seamless experience for every visitor.</p>
<p><b>A/B Testing:</b> We don't just stop at creating a single landing page design. Through rigorous A/B testing, we continuously refine and optimize your landing page to improve its performance and maximize your return on investment (ROI).</p>
                                <div class="services__details-inner-img-wrap">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="assets/img/services/landing1.png" alt="">
                                        </div>
                                        <div class="col-md-6">
                                            <img src="assets/img/services/landing2.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                <h2>How We Help You Increase Conversions Through Landing Pages</h2>
                                <p><b>Clear Call-to-Action (CTA):</b> We craft compelling CTAs that guide visitors towards taking the desired action, whether it's making a purchase, signing up for a newsletter, or requesting more information.</p>
<p><b>Engaging Visuals:</b> We understand the power of visuals in capturing attention and conveying your message effectively. Our designers skillfully integrate eye-catching graphics, videos, and images to enhance the visual appeal of your landing page.</p>
<p><b>Persuasive Copywriting:</b> Words matter. Our copywriters leverage persuasive language and persuasive storytelling techniques to create compelling headlines, informative content, and persuasive CTAs that resonate with your audience and compel them to act.</p>
<p><b>Streamlined User Experience:</b> We prioritize user experience in every aspect of our design process. From intuitive navigation to fast-loading pages, we ensure that every interaction with your landing page is smooth and hassle-free, keeping visitors engaged and encouraging them to convert.</p>
                            </div>
                        </div>
                        <div class="col-30">
                            <aside class="services__sidebar">
                                <div class="sidebar__widget">
                                    <div class="sidebar__cat-list-two">
                                        <ul class="list-wrap">
                                            <li><a href='search-engine-optimization.php'>SEO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-marketing.php'>SMM <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='social-media-optimization.php'>SMO <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='pay-per-click.php'>PPC <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='website-design.php'>Web Design <i class="flaticon-arrow-button"></i></a></li>
                                            <li><a href='graphic-design.php'>Graphic Design <i class="flaticon-arrow-button"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sidebar__widget sidebar__widget-two">
                                    <div class="sidebar__contact sidebar__contact-two" data-background="assets/img/services/sidebar_contact_bg.jpg">
                                        <h2 class="title">If You Need Any Help Contact With Us</h2>
                                        <a href="tel:+91 93373 19419" class="btn"><i class="flaticon-phone-call"></i>+91 93373 19419</a>
                                    </div>
                                </div>
                                <div class="sidebar__widget">
                                    <h4 class="sidebar__widget-title">Brochure</h4>
                                    <div class="sidebar__brochure">
                                        <p>when an unknown printer took ga lley offer typey anddey.</p>
                                        <a href="assets/img/services/services_details01.jpg" target="_blank" download><i class="far fa-file-pdf"></i>PDF. Download</a>
                                        <a href="assets/img/services/services_details01.jpg" target="_blank" download><i class="far fa-file-alt"></i>DOC. Download</a>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- services-details-area-end -->
        <!-- call-back-area -->
        <section class="call-back-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="call-back-content">
                            <div class="section-title white-title mb-10">
                                <h2 class="title">Request A Call Back</h2>
                            </div>
                            <p>Ever find yourself staring at your computer screen a good consulting slogan to come to mind? Oftentimes.</p>
                            <div class="shape">
                                <img src="assets/img/images/call_back_shape.png" alt="" data-aos="fade-right" data-aos-delay="400">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="call-back-form">
                            <form action="#">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="text" placeholder="Name *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="email" placeholder="E-mail *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="number" placeholder="Phone *">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn">Send Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- call-back-area-end -->
    </main>
    <!-- main-area-end -->

<?php include 'footer.php'; ?>
